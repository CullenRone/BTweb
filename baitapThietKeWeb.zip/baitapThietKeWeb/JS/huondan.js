function init(){
  $(window).scroll(function(){
    if($(this).scrollTop() >= 310){
      $("aside").css({
          "display": "block",
          "left": 3,
          "right": 3,
          "top": 30,
          "z-index": 999,
          "opacity": 1
      })
  } else{
      $("aside").css({
          "display": "none",
          
      })
  }

  })
$(document).ready(function(){
  wow = new WOW({
      boxClass:     'wow',      // default
      animateClass: 'animate__animated', // default
      offset:       0,          // default
      mobile:       true,       // default
      live:         true        // default
    })
    wow.init();
})

let colors=['#500000', '#A9A9A9', '#FF9F00', '#00A652', '#993300', '#663399']
function init(){
let a=document.querySelectorAll(".sub h2");
for(let s of a)
{
    let idx= parseInt(Math.random()*colors.length);
    s.style.backgroundColor = colors[idx];
}
}
}


